To apply the patch do the following:
cd xv6
cat paging.patch | patch -p1